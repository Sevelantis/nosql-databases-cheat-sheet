public class Main {
    public static void main(String[] args) {
        EX3 ex3 = new EX3();
        ex3.run();
    }
}
