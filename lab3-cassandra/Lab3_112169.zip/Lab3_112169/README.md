# Author
Miron Oskroba, 112169
# Group
Thursday 11:00AM (P2)
# Notes
* `Enabling materialized views in cassandra is necessary in order to run the lab. The file has been provided.`
